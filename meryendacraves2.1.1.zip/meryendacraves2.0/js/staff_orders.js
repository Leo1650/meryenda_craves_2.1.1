var param = new URLSearchParams(window.location.search);
var stat = param.get('st');
var sid = param.get('si');

var selected = document.getElementById("select_cat");        
    select_cat.addEventListener("change", function(){
        st = btoa(selected.value)
        si = btoa(selected.value)
        window.location.href = "../staff/staff_orders.php?si="+si+"&&st="+st+"&&on=";
        
});

var update_status = document.getElementById('update_status');

function update_stat(){
    update_status.style.display = "block";
}
function cancel_stat(){
    update_status.style.display = "none";
}