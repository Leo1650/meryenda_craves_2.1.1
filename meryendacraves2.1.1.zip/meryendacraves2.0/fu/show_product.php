<?php
include("db_conn.php");
session_start();
    $id =mysqli_real_escape_string($mysqli, $_GET['pid']);

    $show_product = $mysqli->query("UPDATE products SET status = '1' WHERE id='$id'");
    
if($show_product){
    $_SESSION['message'] = "<div class='success_message'>Product Displayed</div>";
    header('Location: ../admin/products&category.php?pid=&&cid=');
}else{
    echo "Failed";
}


?>