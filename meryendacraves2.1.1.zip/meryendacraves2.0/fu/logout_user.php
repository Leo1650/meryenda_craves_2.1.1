<?php
session_start();
include("db_conn.php");

$ui =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($ui);

    $logout = $mysqli->query("UPDATE users SET status = '0' WHERE id = '$user_id' LIMIT 1");

    if($logout){
        unset($_SESSION['auth']);
        header("Location: ../index.php");
    }
?>