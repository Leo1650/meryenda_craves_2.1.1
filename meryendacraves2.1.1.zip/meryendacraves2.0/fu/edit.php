<?php
session_start();
include("db_conn.php");

$pid =mysqli_real_escape_string($mysqli, $_GET['pid']);
$cid =mysqli_real_escape_string($mysqli, $_GET['cid']);

if(isset($_POST['editProduct'])){
    $p_id = base64_decode($pid);

    $name = $_POST['name'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $regular_stock = $_POST['regular_stock'];
    $medium_stock = $_POST['medium_stock'];
    $large_stock = $_POST['large_stock'];
    $xl_stock = $_POST['xl_stock'];

    $regular_price = $_POST['regular_price'];
    $medium_price = $_POST['medium_price'];
    $large_price = $_POST['large_price'];
    $xl_price = $_POST['xl_price'];

    $disc = $_POST['disc'];


    $image =  $_FILES['image']['name'];
    $image_type = $_FILES['image']['type'];
    $image_size = $_FILES['image']['size'];
    $image_loc = $_FILES['image']['tmp_name'];
    $image_store = "products_img/".$image;

    $selectProduct = $mysqli->query("SELECT * FROM products WHERE id='$p_id'");
    $row = mysqli_fetch_array($selectProduct);
    
    if($image == ""){
        $image = $row['image'];
    }

    $update_product = $mysqli->query("UPDATE products SET name = '$name', description = '$description', category = '$category', regular_stock = '$regular_stock', medium_stock = '$medium_stock', large_stock = '$large_stock', xl_stock = '$xl_stock', regular_price = '$regular_price',  medium_price = '$medium_price',  large_price = '$large_price',  xl_price = '$xl_price', disc = '$disc', image = '$image' WHERE id = '$p_id' LIMIT 1");
    move_uploaded_file($image_loc, $image_store);

    if($update_product){
        header("Location: ../admin/products&category.php?pid=&&cid=");
        $_SESSION['message'] = "<div class='success_message'>Saved</div>";
    }else{
        echo 'Failed';
    }

}elseif(isset($_POST['edit_category'])){
    $c_id = base64_decode($cid);

    $name = $_POST['name'];
    

    $update_category = $mysqli->query("UPDATE categories SET name = '$name' WHERE id = '$c_id' LIMIT 1");

    if($update_category){
        header("Location: ../admin/products&category.php?pid=&&cid=");
        $_SESSION['message'] = "<div class='success_message'>Saved</div>";
    }else{
        echo 'Failed';
    }
}


?>