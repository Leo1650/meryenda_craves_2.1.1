<?php
include("db_conn.php");
session_start();
    $id =mysqli_real_escape_string($mysqli, $_GET['cid']);

    $check_products = $mysqli->query("SELECT * FROM products WHERE category = '$id'");
    if(mysqli_num_rows($check_products) == 0){
        $delete = $mysqli->query("DELETE FROM categories WHERE id = '$id'");
        if($delete){
            $_SESSION['message'] = "<div class='success_message'>Deleted</div>";
            header('Location: ../admin/products&category.php?pid=&&cid=');
        }else{
            echo "Failed";
        }
    }else{
        $_SESSION['message_err'] = "<div class='error_message'>Failed! There are products under this category</div>";
        header('Location: ../admin/products&category.php?pid=&&cid=');
    }

    


?>