<?php
include("../fu/db_conn.php");
/* include("sidebar.php"); */
session_start();

$on =mysqli_real_escape_string($mysqli, $_GET['on']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/invoice_print.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">

    <link rel=”stylesheet” href=”https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css”>
    <link rel=”stylesheet” href=”https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js”>
    <script src="../src/invoice_print.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>


    <title> Invoice</title>
</head>

<body>

<div class="invoice-container-wrapper">

        <div class="invoice-container" id="invoice">
      
        <div class="invoice-row">
        <div class="invoice-order-info">
                    <?php
                    
                    $print_order = $mysqli->query("SELECT * FROM orders WHERE order_no = '$on'");
                    if(mysqli_num_rows($print_order) != 0){
                        $row_print_order = mysqli_fetch_array($print_order);
                
                        if($row_print_order['mode_of_payment'] == 'Paypal'){
                            if($row_print_order['delivery_permission'] == 1){
                                $payment_status = 'Paid';
                            }else{
                                 $payment_status = 'Pending';
                            }
                        }
                        
                    }
                    
                    ?>


                    <span>Order I.D: <?php echo $on; ?></span>
                    <br>
                    <span>Date&Time: <?php echo $row_print_order['date_ordered']; ?></span>
                    <br>
                    <span>Mode Of Payment: <?php echo $row_print_order['mode_of_payment']; ?></span>
                    <br>
                    <?php
                    if($row_print_order['mode_of_payment'] == 'Paypal'){
                        echo '<span>Status: '.$payment_status.'</span><br>';
                    }elseif($row_print_order['mode_of_payment'] == 'Pick-up'){
                        echo '<span>Pick-up Time: '.$row_print_order['pick_up_time'].'</span><br>';
                    }
                    ?>

                </div>

                <div class="invoice-store-logo">
                    <img src="../img/MCLogo.png" alt="">
                </div>


        </div>

        <div class="invoice-row">
            <div class="invoice-order-info">
                        <span><?php echo $row_print_order['name'];?></span>
                        <br>
                        <span><?php echo $row_print_order['address']; ?></span>
                        <br>
                        <span><?php echo $row_print_order['phone']; ?></span>
                    </div>
    
                    <div class="invoice-store-info">
                        <span style="float: right;">Meryenda Craves Z.C.</span>
                        <br>
                        <span style="float: right;">April Dive, Guiwan</span>
                        <br>
                        <span style="float: right;">Zamboanca City</span>
                        <br>
                        <span style="float: right;">+63 977 4233 302</span>
                        
                    </div>
    
    
            </div>
                

        <div class="tbl-wrapper">
            <table id="inv-tbl">

            
                <tr>
                    <th>Items</th>
                    <th>Size</th>
                    <th>Quantity</th>
                    <th>Price</th>
                </tr>

                <?php
                $total_items = 0;
                $order_details = $mysqli->query("SELECT * FROM order_details WHERE order_no = '$on'");
                if(mysqli_num_rows($order_details) != 0){
                    while($orders = mysqli_fetch_array($order_details)){
                        echo '
                        <tr>
                        <td align="left">'.$orders["product_name"].'</td>
                        <td>'.$orders["size"].'</td>
                        <td>x'.$orders["quantity"].'</td>';

                        $prod = $orders['product_id'];
                        $check_price = $mysqli->query("SELECT * FROM products WHERE id = '$prod'");
                        $row_check_price = mysqli_fetch_array($check_price);
                        if($orders["size"] = 'Regular'){
                            $item_price = $row_check_price['regular_price'];

                        }elseif($orders["size"] = 'Medium'){
                            $item_price = $row_check_price['medium_price'];

                        }elseif($orders["size"] = 'Large'){
                            $item_price = $row_check_price['large_price'];

                        }elseif($orders["size"] = 'XL'){
                            $item_price = $row_check_price['xl_price'];

                        }

                        echo'
                        <td>'.$item_price.'</td>
                        </tr>


                        ';

                        $total_items += $orders["quantity"];

                    }
                }
               ?>
            

                
                
                <tr>
                    <td></td>
                </tr>

                <tr style=" height:20px;font-size: 10pt;">
                    <td style="float:left;">Amount:</td>
                    <td></td>
                    <td></td>
                    <td><?php echo $row_print_order['amount']; ?></td>
                </tr>

                <tr style=" height:20px;font-size: 10pt;">
                    <td style="float:left;">Delivery Fee:</td>
                    <td></td>
                    <td></td>
                    <td><?php echo $row_print_order['del_fee']; ?></td>
                </tr>

                <tr style=" height:30px;font-size: 10pt;color:red;">
                    <td style="float:left;">Total:</td>
                    <td></td>
                    <td></td>
                    <td><?php echo number_format($row_print_order['amount']+$row_print_order['del_fee'],2); ?></td>
                </tr>


            </table>

            <div class="invoice-row">
            <div class="invoice-order-ins">
                        <span style="float:left; font-weight:bold;">Delivery Instruction</span>
                        <br>
                        <p style="font-size: 8pt;"><?php echo $row_print_order['del_ins'] ?></p>
                        
                    </div>
                     
    
    
            </div>


        </div>

       



        
       
    </div>
   
    
        <div class="btn-wrapper">
             <button id="download-invoice">Download</button>
        </div>

    

    </div>
    

            </body>
            </html>