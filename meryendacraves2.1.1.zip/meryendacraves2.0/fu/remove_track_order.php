<?php
include("db_conn.php");
session_start();
    $on =mysqli_real_escape_string($mysqli, $_GET['on']);
    $ui =mysqli_real_escape_string($mysqli, $_GET['ui']);

    $user_id = base64_encode($ui);
    $update = $mysqli->query("UPDATE orders SET status = 4 WHERE user_id = '$ui' AND order_no = '$on' LIMIT 1");
if($update){
    $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check-circle'></i><br>Moved to Order History</div>";
    header('Location: ../user/trackOrder.php?ui='.$user_id.'');
}else{
    echo "Failed";
}


?>