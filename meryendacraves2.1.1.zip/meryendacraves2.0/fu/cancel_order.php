<?php
include("db_conn.php");
session_start();
    $on =mysqli_real_escape_string($mysqli, $_GET['on']);
    $ui =mysqli_real_escape_string($mysqli, $_GET['ui']);

    $user_id = base64_encode($ui);

    $select_order = $mysqli->query("SELECT * FROM order_details WHERE order_no = '$on'");
    if(mysqli_num_rows($select_order) != 0){
        $row_selected_order = mysqli_fetch_array($select_order);
        $product_id =  $row_selected_order['product_id'];
        $size =  $row_selected_order['size'];

        $select_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
        if(mysqli_num_rows($select_product) != 0){
            $row_selected_product = mysqli_fetch_array($select_product);
            $p_id =  $row_selected_product['id'];

        $sales = $row_selected_product['sold'] - $row_selected_order['quantity'];
        $update_sales = $mysqli->query("UPDATE products SET sold = '$sales' WHERE id = '$p_id'");
        }

        if($size == 'Regular'){
            $new_stock = $row_selected_product['regular_stock'] + $row_selected_order['quantity'];;
            $update_stock = $mysqli->query("UPDATE products SET regular_stock = '$new_stock' WHERE id = '$p_id'");
        }

        if($size == 'Medium'){
            $new_stock = $row_selected_product['medium_stock'] + $row_selected_order['quantity'];;
            $update_stock = $mysqli->query("UPDATE products SET medium_stock = '$new_stock' WHERE id = '$p_id'");
        }

        if($size == 'Large'){
            $new_stock = $row_selected_product['large_stock'] + $row_selected_order['quantity'];;
            $update_stock = $mysqli->query("UPDATE products SET large_stock = '$new_stock' WHERE id = '$p_id'");
        }

        if($size == 'XL'){
            $new_stock = $row_selected_product['xl_stock'] + $row_selected_order['quantity'];;
            $update_stock = $mysqli->query("UPDATE products SET xl_stock = '$new_stock' WHERE id = '$p_id'");
        }

    //$delete_order = $mysqli->query("DELETE orders, order_details FROM orders INNER JOIN order_details WHERE  orders.order_no = order_details.order_no AND  orders.order_no = '$on' AND  orders.user_id = '$ui'");
    $cancel_order = $mysqli->query("UPDATE orders SET status = 6 WHERE order_no = '$on' AND user_id = '$ui'");
    if($cancel_order){   
    $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check-circle'></i><br>Order Canceled</div>";
    header('Location: ../user/trackOrder.php?ui='.$user_id.'');
    }else{
    echo "Failed";
    }
    }


?>