 <?php
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbName = "u481024253_meryendacraves";
    $mysqli = new mysqli($host, $dbUsername, $dbPassword, $dbName);
?>