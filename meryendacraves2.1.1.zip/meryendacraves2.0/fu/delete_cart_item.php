<?php
include("db_conn.php");
session_start();
    $id =mysqli_real_escape_string($mysqli, $_GET['cart_id']);
    $ui =mysqli_real_escape_string($mysqli, $_GET['ui']);


    $delete = $mysqli->query("DELETE FROM cart WHERE id = '$id'");
if($delete){
    $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check-circle'></i><br>Product Deleted</div>";
    header('Location: ../user/cart.php?ui='.$ui.'');
}else{
    echo "Failed";
}


?>