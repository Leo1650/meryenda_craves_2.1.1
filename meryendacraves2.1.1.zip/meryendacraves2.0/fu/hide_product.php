<?php
include("db_conn.php");
session_start();
    $id =mysqli_real_escape_string($mysqli, $_GET['pid']);

    $hide_product = $mysqli->query("UPDATE products SET status = '0' WHERE id='$id'");
    
if($hide_product){
    $_SESSION['message'] = "<div class='success_message'>Product Hidden</div>";
    header('Location: ../admin/products&category.php?pid=&&cid=');
}else{
    echo "Failed";
}


?>