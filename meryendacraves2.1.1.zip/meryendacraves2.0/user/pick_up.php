<?php
include("../fu/db_conn.php");
$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($id);
$on =mysqli_real_escape_string($mysqli, $_GET['on']);
$order_no = base64_decode($on);

if(isset($_GET['ui'])){
    $check_status = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
    if(mysqli_num_rows($check_status) != 0){
        $row_check = mysqli_fetch_array($check_status);
        if($row_check['status'] == 0){
            header("Location: login.php");
            exit();
        }
    }
    }else{
        header("Location: login.php");
    }



if(isset($_POST['submit'])){
    $time = $_POST['time'];

    $update_pick_up_time = $mysqli->query("UPDATE orders SET pick_up_time = '$time' WHERE order_no = '$order_no' LIMIT 1");

    if($update_pick_up_time){
        $from_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
        $count = 0;
        if(mysqli_num_rows($from_cart) != 0){

            while($row_from_cart = mysqli_fetch_array($from_cart)){
                $count += 1;
                $product_id = $row_from_cart['product_id'];
                $product_image = $row_from_cart['product_image'];
                $product_name = $row_from_cart['product_name'];
                $quantity = $row_from_cart['quantity'];
                $size = $row_from_cart['size'];

                $to_order_details = $mysqli->query("INSERT INTO order_details (order_no, product_id, product_image, product_name, quantity, size) VALUES ('$order_no', '$product_id', '$product_image', '$product_name', '$quantity', '$size')");
            
                if($to_order_details){
                    $select_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
                    if(mysqli_num_rows($select_product) != 0){
                        $row_selected = mysqli_fetch_array($select_product);
                    }
                    if($size == 'Regular'){
                        $new_stock = $row_selected['regular_stock'] - $quantity;
                        $update_stock = $mysqli->query("UPDATE products SET regular_stock = '$new_stock' WHERE id = '$product_id'");
                    }
                    if($size == 'Medium'){
                        $new_stock = $row_selected['medium_stock'] - $quantity;
                        $update_stock = $mysqli->query("UPDATE products SET medium_stock = '$new_stock' WHERE id = '$product_id'");
                    }
                    if($size == 'Large'){
                        $new_stock = $row_selected['large_stock'] - $quantity;
                        $update_stock = $mysqli->query("UPDATE products SET large_stock = '$new_stock' WHERE id = '$product_id'");
                    }
                    if($size == 'XL'){
                        $new_stock = $row_selected['xl_stock'] - $quantity;
                        $update_stock = $mysqli->query("UPDATE products SET xl_stock = '$new_stock' WHERE id = '$product_id'");
                    }
                    
                }
            
            
            }
        }
        if($count == mysqli_num_rows($from_cart)){
            $remove_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$user_id'");
            if($remove_cart){
                header("Location: trackOrder.php?ui=$id&&on=$on");
                exit();
            }
        }

        
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/pick_up.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <title>Pick-up</title>
</head>
<body>
    <div class="container">
        <div class="form_container">
            <div class="formbox">
                <div class="form_control" >
                    <div class="logo">
                    <img src="../img/MCLogo.png" alt="Logo">
                    </div>
                    <span >is Located at </span>
                    
                    <strong>April Drive, Guiwan Zamboanga City</strong>
                    <br>
                    <span>Set Pick-up Date&Time</span>
                    <br>
                    <form action="pick_up.php?ui=<?php echo $id; ?>&&on=<?php echo $on; ?>" method="POST">
                        <input type="datetime-local" class="input" name="time" required>
                            
                            <div class="action-btn">
                                <input type="submit" value="Submit" id="create" name="submit">
                            </div>
                    </form>

                </div>
            
            </div>
        </div>
    </div>
   
</body>
</html>