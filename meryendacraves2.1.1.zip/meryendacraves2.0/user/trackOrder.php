<?php
include("navbar.php");
include("../fu/db_conn.php");

$ui =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($ui);



if(isset($_GET['on'])){

  echo '<div class="loc-form-wrapper">
  <div class="loc-formbox">
  <a href="trackOrder.php?ui='.$ui.'" class="button"><i class="fas fa-times"></i></a>
  <h1 style="font-size: 20pt;">Pick-up Point</h1>
  <p>April Drive, Guiwan Zamboanga City</p>
  
  <div class="loc-img-wrapper">
  <img src="../img/MCZC_MAP.png" alt="">
  </div>
  </div>
  </div>';
  
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="stylesheet" href="../css/trackOrder.css">
  <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
  <script src="https://kit.fontawesome.com/ed284aa2e1.js" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">



  <title>Track Order</title>
</head>

<body>

<div class="order_history_section">
    <h3>Track Orders</h3>
    <div class="order-history">
      <a href="OrderHistory.php?ui=<?php echo $id; ?>"><i class="fas fa-history"></i> History</a>
    </div>    
</div>


<div class="container_wrapper">
  <?php 
  $check_order = $mysqli->query("SELECT * FROM orders WHERE user_id = '$user_id'");
  $count = 0;
  if(mysqli_num_rows($check_order) != 0){
    while($row_check_order = mysqli_fetch_array($check_order)){
        $submitted = 'inactive';
        $processed = 'inactive';
        $deliver = 'inactive';
        $received = 'inactive';
        $pick_up = 'inactive';

      if($row_check_order['status'] == 0){
        $submitted = 'done';
      
      }
      elseif($row_check_order['status'] == 1){
        $submitted = 'done';
        $processed = 'done';
      }
      elseif($row_check_order['status'] == 2){
        $submitted = 'done';
        $processed = 'done';
        $deliver = 'done';
      
      }
      elseif($row_check_order['status'] == 3){
        $submitted = 'done';
        $processed = 'done';
        $pick_up = 'done';
      }
      elseif($row_check_order['status'] == 4){
        $submitted = 'done';
        $processed = 'done';
        $deliver = 'done';
        $pick_up = 'done';
        $received = 'done';
      }
      
      if($row_check_order['status'] < 4){
        $count = 1;
          echo '
          <div class="container">';

        if($row_check_order['mode_of_payment'] == 'Pick-up' ){
        echo '<div class="loc-wrapper">
          <a href="trackOrder.php?ui='.$ui.'&&on='.$row_check_order['order_no'].'" class="button"><i class="fas fa-map-marked-alt"></i></a>
        </div>';
        }

          echo'<div class="progress">';
      
            echo' <div class="details-wrapper">
            <h1 ><i class="fas fa-tags"></i> &nbsp;Orders</h1>
            <p><i>Order I.D.: '.$row_check_order['order_no'].'</i></p>
            <p><i>Date&Time: '.$row_check_order['date_ordered'].'</i></p>
            <p><i>Payment: '.$row_check_order['mode_of_payment'].'</i></p>
            <p><i>Items Qty: x'.$row_check_order['quantity'].'</i></p>
            <p><i>Amount: '.$row_check_order['amount'].'</i></p>';

            if($row_check_order['mode_of_payment'] == 'COD'){
              echo '<p><i>Delivery Fee: '.$row_check_order['del_fee'].'</i></p>';
            }
            echo'
            <p><i>Total: '.number_format($row_check_order['amount']+$row_check_order['del_fee'], 2).'</i></p>';
            

            if($row_check_order['mode_of_payment'] == 'Pick-up'){
              echo '
              <p><i>Pick-up Time&Date: '.$row_check_order['pick_up_time'].'</i></p>';

            }


            echo '
        
            <br>
            <p><i>Status:</i></p>
            </div>

        <ul class="ul">
          <li class="'.$submitted.'" id="submitted" >
            <i class="far fa-dot-circle"></i>
            <p>Order Created</p>
          </li>
          <li class="'.$processed.'" id="processed">
            <i class="far fa-dot-circle"></i>
            <p>Processing</p>
          </li>
          
          '.(($row_check_order['mode_of_payment'] == 'Pick-up')?
            '<li class="'.$pick_up.'" id="pick_up">
                    <i class="far fa-dot-circle"></i>
                    <p>Ready for Pick-up</p>
            </li>':

           '<li class="'.$deliver.'" id="Deliver">
            <i class="far fa-dot-circle"></i>
            <p>Out for Delivery</p>
          </li>'

          ).'
          
      
        </ul>';
      
        
       
        if($row_check_order['status'] == 2){
          
          echo '<a href="../fu/remove_track_order.php?ui='.$row_check_order['user_id'].'&&on='.$row_check_order['order_no'].'" class="order_received_button">Order Received</a>';
          
        }

        if($row_check_order['status'] == 3){
          echo '<a href="../fu/remove_track_order.php?ui='.$row_check_order['user_id'].'&&on='.$row_check_order['order_no'].'" class="order_received_button">Order Received</a>';
         
        }
        if($row_check_order['status'] == 0){
          echo '<a href="../fu/cancel_order.php?ui='.$row_check_order['user_id'].'&&on='.$row_check_order['order_no'].'" class="cancel_order_button">Cancel Order</a>';
        }
      
        echo '</div>';
        echo '</div>';
        
      }

      
      
    }

    if($count == 0){
      echo '
          
          <div class="no-orders">
          <p>No Orders</p>
          </div>
      
      ';
    }
  }else{
    echo '  
    <div class="no-orders">
    <p>No Orders</p>
    </div>
    ';
  }

?>
</div>


<?php 
  if(isset($_SESSION['cart_feedback'])){
    echo $_SESSION['cart_feedback'];
    unset($_SESSION['cart_feedback']);
  }
?>

</body>
</html>

<?php
include("footer.php");
?>
