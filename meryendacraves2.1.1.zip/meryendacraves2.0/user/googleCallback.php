<?php
include('../fu/db_conn.php');
session_start();
if(isset($_POST['email'])){
    $email = $_POST['email'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $password = $_POST['password'];
    $verified = 1;
    
    $check_login = $mysqli->query("SELECT * FROM users WHERE email = '$email' AND password = 'Google'");
    if(mysqli_num_rows($check_login) != 0){
      $row_login = mysqli_fetch_array($check_login);
      $id = $row_login['id'];
      $ui = base64_encode($id);
      $update = $mysqli->query("UPDATE users SET status='1' WHERE id='$id'");
      if($update){
        $guess_id = $_SESSION['guessID'];

        $select_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$guess_id'");
        
        if(mysqli_num_rows($select_cart) != 0){
            while($row_cart = mysqli_fetch_array($select_cart)){
                $product_id = $row_cart['product_id'];
                $category_id = $row_cart['category_id'];
                $product_image = $row_cart['product_image'];
                $product_name = $row_cart['product_name'];
                $price = $row_cart['price'];
                $size = $row_cart['size'];
                $quantity = $row_cart['quantity'];

                $insert_to_cart = $mysqli->query("INSERT INTO cart (user_id, product_id, category_id, product_image, product_name, price, size, quantity) VALUES ('$id', '$product_id', '$category_id', '$product_image', '$product_name', '$price', '$size', '$quantity')");
            }

            $delete_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$guess_id'");
        }

        unset($_SESSION['guessID']);
        $_SESSION['auth'] = $ui;
        echo "home.php?ui=$ui&&cid=MA==";
      }
    }else{
        $check_email = $mysqli->query("SELECT * FROM users WHERE email = '$email' AND password != 'Google' AND password != 'Facebook'");
        
        if(mysqli_num_rows($check_email) != 0){
        
            $row = mysqli_fetch_array($check_email);
            $un = $row["firstname"];
            
            echo "You already have an account with us";
            $_SESSION['error'] = "You already have an account with us. Your Username is '$un'";
        }else{
          $insert = $mysqli->query("INSERT INTO users(firstname, lastname, email, password, verified) VALUES ('$firstname', '$lastname', '$email', 'Google', '$verified')");
      
          if($insert){
            $select_org = $mysqli->query("SELECT * FROM users WHERE email = '$email' and password = 'Google'");
            $row_select = mysqli_fetch_array($select_org);
            if(mysqli_num_rows($select_org) != 0){
              $id = $row_select['id'];
              $org_id = base64_encode($id);
              $update = $mysqli->query("UPDATE users SET status='1' WHERE id='$id'");
              if($update){
                $guess_id = $_SESSION['guessID'];

                $select_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$guess_id'");
                
                if(mysqli_num_rows($select_cart) != 0){
                    while($row_cart = mysqli_fetch_array($select_cart)){
                        $product_id = $row_cart['product_id'];
                        $category_id = $row_cart['category_id'];
                        $product_image = $row_cart['product_image'];
                        $product_name = $row_cart['product_name'];
                        $price = $row_cart['price'];
                        $size = $row_cart['size'];
                        $quantity = $row_cart['quantity'];
        
                        $insert_to_cart = $mysqli->query("INSERT INTO cart (user_id, product_id, category_id, product_image, product_name, price, size, quantity) VALUES ('$id', '$product_id', '$category_id', '$product_image', '$product_name', '$price', '$size', '$quantity')");
                    }
        
                    $delete_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$guess_id'");
                }
        
                unset($_SESSION['guessID']);
                $_SESSION['auth'] = $org_id;
                echo "home.php?ui=$org_id&&cid=MA==";
              }
            }
            
          }
        }
      
      
    }
}


?>