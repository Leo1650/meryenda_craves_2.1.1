<?php
include("../fu/db_conn.php");
include('../smtp/PHPMailerAutoload.php');
session_start();


if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

        $email = $mysqli->real_escape_string($email);
        $password = $mysqli->real_escape_string($password);


        $password = md5($password);
        
        $select = $mysqli->query("SELECT * FROM users WHERE email = '$email' and password = '$password'");
        $row = mysqli_fetch_array($select);
        
        if ($row['email'] == $email && $row['password'] == $password && $row['verified'] == 1) {
            $id = $row['id'];
            $user_id = base64_encode($id);

            $guess_id = $_SESSION['guessID'];

            $select_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$guess_id'");
            
            if(mysqli_num_rows($select_cart) != 0){
                while($row_cart = mysqli_fetch_array($select_cart)){
                    $product_id = $row_cart['product_id'];
                    $category_id = $row_cart['category_id'];
                    $product_image = $row_cart['product_image'];
                    $product_name = $row_cart['product_name'];
                    $price = $row_cart['price'];
                    $size = $row_cart['size'];
                    $quantity = $row_cart['quantity'];

                    $insert_to_cart = $mysqli->query("INSERT INTO cart (user_id, product_id, category_id, product_image, product_name, price, size, quantity) VALUES ('$id', '$product_id', '$category_id', '$product_image', '$product_name', '$price', '$size', '$quantity')");
                }

                $delete_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$guess_id'");
            }

            unset($_SESSION['guessID']);

            //$_SESSION['userStatus'] = 'true';

            
            $_SESSION['auth'] = $user_id;
            
              
            $update = $mysqli->query("UPDATE users SET status= 1 WHERE id='$id'");
            header("Location: home.php?ui=$user_id&&cid=MA==");
            exit();

        }elseif($row['email'] != $email || $row['password'] != $password){
            header("Location: login.php");
            $_SESSION['error'] = '<p class="error">Incorrect Email or Password</p>';
            exit();

        }elseif($row['verified'] == 0){
            header("Location: login.php");
            $_SESSION['error'] = '<p class="error">Account is not yet verified</p>';
            exit();
        }

}


function smtp_mailer($to,$subject, $msg){
    $mail = new PHPMailer(true);
    //$mail->SMTPDebug = 1;
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Username = "ssmtp1560@gmail.com";
    $mail->Password = "smtpsupport123";
    $mail->SetFrom("ssmtp1560@gmail.com");
    $mail->Subject = $subject;
    $mail->Body = $msg;
    $mail->AddAddress($to);
    $mail->SMTPOptions=array('ssl'=>array(
        'verify_peer'=>false,
        'verify_peer_name'=>false,
        'allow_self_signed'=>false
    ));
    if(!$mail->Send()){
        return 0;
    }else{
        return 1;
    }
}

//Generate OTP
function check_code($mysqli, $randStr){
    $keyExist = false;
    $result = $mysqli->query("SELECT * FROM admin_accs");
    if(mysqli_num_rows($result) != 0){
        while($row = mysqli_fetch_array($result)){
            if($row['OTP'] == $randStr){
                $keyExist = true;
                break;
            }else{
                $keyExist = false;
            }
        }
    }
    return $keyExist;
}

function generate_code($mysqli){
    $keylength = 5;
    $str = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $randStr = substr(str_shuffle($str), 0, $keylength);


    $checkKey = check_code($mysqli, $randStr);

    while($checkKey == true){
        $randStr = substr(str_shuffle($str), 0, $keylength);
        $checkKey = check_code($mysqli, $randStr);
    }

    return $randStr;
}
//End OTP
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="../css/register.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Login</title>
</head>
<body>
   
    <div class="flexbox">
        <div class="form">

            <div class="form_control_log">
            <a href="../admin/admin_login.php" style="color: grey; font-size: 15pt;"><i class="fas fa-user-cog"></i></a>
                <div class="form_title">
                    <h4>Login</h4>
                </div>
                <form action="login.php" method="POST">
                    <div class="inputs">
                    
                        <div class="email_wrapper">
                            <span>Email</span>
                            <input type="text" placeholder="Email" name="email" required>
                        </div>

                        <div class="password_wrapper">
                            <span>Password</span>
                            <input type="password" placeholder="Password" id="password" name="password" required>
                            <i class="fas fa-eye fa-lg fa-fw" id="eye" onclick="toggle()"></i>
                        </div>
                        

                        <div class="form_btn">
                            <button type="submit" id="submit" name="login">Login</button>
                        </div>
                        <a href="#" id="forgot">Forgot Password?</a>
                        <div class="btn">
                        <p>Don't have an account?  <a href="register.php">Register</a></p>
                         </div>
                         <span style="text-align:center;">or</span>
                        
                        
                    </div>
                </form>
                <?php
                    if(isset($_SESSION['error'])){
                        echo $_SESSION['error'];
                        unset( $_SESSION['error']);
                    }
                ?>

                <div class="form_btn">
                <div id="gSignInWrapper">
                        <div id="customBtn" class="customGPlusSignIn">
                          <span class="icon"><i class="fab fa-google"></i></span>
                          <div class="textwrapper">
                            <span class="buttonText">Continue with google</span>
                          </div>
                          
                        </div>
                </div>
                </div>
            </div>

        </div>
    </div>

    <script>
        var state = false;
        function toggle(){
            if(state){
                document.getElementById('password').setAttribute("type", "password");
                state = false;
            }else{
                document.getElementById('password').setAttribute("type", "text");
                state = true;
            }
        }
    </script>

<script src="https://apis.google.com/js/api:client.js"></script>
    <script>
          var googleUser = {};
          var startApp = function() {
            gapi.load('auth2', function(){
              // Retrieve the singleton for the GoogleAuth library and set up the client.
              auth2 = gapi.auth2.init({
                client_id: '409590955913-3t7knd3o64u1v2s2nqsb9va6180hbbps.apps.googleusercontent.com',
                cookiepolicy: 'single_host_origin',
                // Request scopes in addition to 'profile' and 'email'
                //scope: 'additional_scope'
              });
              attachSignin(document.getElementById('customBtn'));
              console.log('Test');
            });
          };
        
          function attachSignin(element) {
            auth2.attachClickHandler(element, {},
                function(googleUser) {
                  var profile = googleUser.getBasicProfile();
                  console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
                  console.log('Name: ' + profile.getName());
                  console.log('Given Name: ' + profile.getGivenName());
                  console.log('Family Name: ' + profile.getFamilyName());
                  console.log('Image URL: ' + profile.getImageUrl());
                  console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
                  
                    var firstname = profile.getGivenName();
                    var lastname = profile.getFamilyName();
                    var email = profile.getEmail();
                    var password = profile.getId();

                    

                    $.ajax({
                        type : "POST",  //type of method
                        url  : "googleCallback.php",  //your page
                        data : { firstname : firstname, lastname : lastname, email : email, password : password },// passing the values
                        success: function(res){  
                             //do what you want here...
                             console.log(res);
                             if(res.includes("You already have an account with us")){
                                 window.location.href = "login.php";
                             }else{
                                 window.location.href = res;
                             }
                        }
                    });
                    
                    

                    
                });
          }
          
    </script>
    <script>startApp();</script>
</body>
</html>