<?php
include("../fu/db_conn.php");
include("navbar.php");


$ui =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($ui);
$item_id =mysqli_real_escape_string($mysqli, $_GET['pid']);
$item_id_dec = base64_decode($item_id);
$size =mysqli_real_escape_string($mysqli, $_GET['se']);
$size_dec = base64_decode($size);

$selected_item = $mysqli->query("SELECT * FROM products WHERE id = '$item_id_dec'");
if(mysqli_num_rows($selected_item) != 0){
    $row_selected_item = mysqli_fetch_array($selected_item);
    $category_id = $row_selected_item['category'];

    
    $select_cat = $mysqli->query("SELECT * FROM categories WHERE id = '$category_id'");
    if(mysqli_num_rows($select_cat)){
        $row_cat = mysqli_fetch_array($select_cat);
    }
}


if(isset($_POST['add_to_cart'])){
    $product_id = $_POST['product_id'];
    $category_id = $_POST['category_id'];
    $product_image = $_POST['product_image'];
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $size = $_POST['size'];
    $quantity = $_POST['quantity'];
    $size_enc = base64_encode($size); 

    
    $check_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
    if(mysqli_num_rows($check_product) != 0){
        $row_product = mysqli_fetch_array($check_product);
        if($size == 'Regular'){
            if($row_product['regular_stock'] == 0){
            header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>".$size." ".$row_product['name']." is Out of Stock</div>";
                exit();
            }elseif($quantity > $row_product['regular_stock']){
                header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>Sorry! We only have ".$row_product['regular_stock']." ".$size." ".$row_product['name']."</div>";
                exit();
            }
        }
        
        if($size == 'Medium'){
            if($row_product['medium_stock'] == 0){
            header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>".$size." ".$row_product['name']." is Out of Stock</div>";
                exit();
            }elseif($quantity > $row_product['medium_stock']){
                header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>Sorry! We only have ".$row_product['medium_stock']." ".$size." ".$row_product['name']."</div>";
                exit();
            }
        }

        if($size == 'Large'){
            if($row_product['large_stock'] == 0){
            header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>".$size." ".$row_product['name']." is Out of Stock</div>";
                exit();
            }elseif($quantity > $row_product['large_stock']){
                header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>Sorry! We only have ".$row_product['large_stock']." ".$size." ".$row_product['name']."</div>";
                exit();
            }
        }

        if($size == 'XL'){
            if($row_product['xl_stock'] == 0){
            header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>".$size." ".$row_product['name']." is Out of Stock</div>";
                exit();
            }elseif($quantity > $row_product['xl_stock']){
                header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
                $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-exclamation-triangle' style='color: red;'></i><br>Sorry! We only have ".$row_product['xl_stock']." ".$size." ".$row_product['name']."</div>";
                exit();
            }
        }
        
    }

    $check_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id' AND product_id = '$product_id' AND size = '$size' ");
    if(mysqli_num_rows($check_cart) != 0){
        $row_cart_check = mysqli_fetch_array($check_cart);
        $quantity += $row_cart_check['quantity'];
        $update_product_qty = $mysqli->query("UPDATE cart SET quantity = '$quantity' WHERE product_id = '$product_id' AND size = '$size'");

        if($update_product_qty){
            header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
            $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check'></i><br> Product has been added to your cart</div>";
            exit();
        }
    }else{
        $insert_to_cart = $mysqli->query("INSERT INTO cart (user_id, product_id, category_id, product_image, product_name, price, size, quantity) VALUES ('$user_id', '$product_id', '$category_id', '$product_image', '$product_name', '$price', '$size', '$quantity')");

        if($insert_to_cart){
            header("Location: item_page.php?ui=$ui&&pid=$item_id&&se=$size_enc");
            $_SESSION['cart_feedback'] = "<div class='cart_feedback'><i class='fas fa-check'></i><br> Product has been added to your cart</div>";
            exit();
        }else{
            echo 'Failed';
        }
    }
   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Page</title>
    <link rel="stylesheet" href="../css/item_page.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
</head>
<body>


<div class="container ">
    <form action="item_page.php?ui=<?php echo $ui; ?>&&pid=<?php echo $item_id; ?>&&se=<?php echo $size; ?>" method="POST">
        <div class="row">
        <div class="col1">
                    <img src="../admin/products_img/<?php echo $row_selected_item['image']; ?>" width="100%">

        </div>
            <br>
            <div class="col2"> 
            <h1><?php echo $row_selected_item['name']; ?></h1>

            

            <?php
                if($size_dec == 'Regular'){
                    if($row_selected_item['disc'] != 0){
                        $price = $row_selected_item['regular_price'] - ($row_selected_item['disc'] / 100) * $row_selected_item['regular_price'] ;
                        $pbs = $row_selected_item['regular_price'];
                        $stock = $row_selected_item['regular_stock'];
                    }else{
                        $price = $row_selected_item['regular_price'];
                        $stock = $row_selected_item['regular_stock'];
                    }
                   
                }
 
                if($size_dec == 'Medium'){
                    if($row_selected_item['disc'] != 0){
                        $price = $row_selected_item['medium_price'] - ($row_selected_item['disc'] / 100) * $row_selected_item['medium_price'] ;
                        $pbs = $row_selected_item['medium_price'];
                        $stock = $row_selected_item['medium_stock'];
                    }else{
                        $price = $row_selected_item['medium_price'];
                        $stock = $row_selected_item['medium_stock'];
                    }
                }

                if($size_dec == 'Large'){
                    if($row_selected_item['disc'] != 0){
                        $price = $row_selected_item['large_price'] - ($row_selected_item['disc'] / 100) * $row_selected_item['large_price'] ;
                        $pbs = $row_selected_item['large_price'];
                        $stock = $row_selected_item['large_stock'];
                    }else{
                        $price = $row_selected_item['large_price'];
                        $stock = $row_selected_item['large_stock'];
                    }
                }

                if($size_dec == 'XL'){
                    if($row_selected_item['disc'] != 0){
                        $price = $row_selected_item['xl_price'] - ($row_selected_item['disc'] / 100) * $row_selected_item['xl_price'] ;
                        $pbs = $row_selected_item['xl_price'];
                        $stock = $row_selected_item['xl_stock'];
                    }else{
                        $price = $row_selected_item['xl_price'];
                        $stock = $row_selected_item['xl_stock'];
                    }
                }


                if($row_selected_item['disc'] != 0){
                    echo '<div class="price_wrapper">
                            <p style="font-size: 20px; color:grey;"><span>&#8369</span>'.$pbs.'</p>
                            <p style="font-size: 20px; color:grey;">&nbsp;-&nbsp;</p>
                            <p style="font-size: 20px; color:#df313c;"><span>&#8369</span>'.$price.'</p>
                        </div>';

                }else{
                    echo '<p style="font-size: 20px;"><span>&#8369</span>'.$price.'.00</p>';

                }
                

            ?>
            
           

            <br>

            <h3>Description</h3>
            <div class="description-wrapper">
                 <p><?php echo $row_selected_item['description'];?> </p>
            </div>
           

            <br>

            <div class="stocks-wrapper">
            <div class="stocks">Available Stocks : <?php echo $stock ?></div>
            <div class="stocks"></div>
            </div>

            <br>

            <div class="add-cart-wrapper">
                <div class="size-qty">
                    <div class="size-wrapper">
                <h3>Select Size</h3>
                    <select name="size" id="size">
                        <?php
                        echo '<option value="'.$size_dec.'">'.$size_dec.'</option>';
                            if($row_selected_item['regular_price'] != 0){
                                if($size_dec != 'Regular'){
                                    echo '<option value="Regular">Regular</option>';
                                }
                            }

                            if($row_selected_item['medium_price'] != 0){
                                if($size_dec != 'Medium'){
                                    echo '<option value="Medium">Medium</option>';
                                }
                            }

                            if($row_selected_item['large_price'] != 0){
                                if($size_dec != 'Large'){
                                    echo '<option value="Large">Large</option>';
                                }
                            }

                            if($row_selected_item['xl_price'] != 0){
                                if($size_dec != 'XL'){
                                    echo '<option value="XL">XL</option>';
                                }
                            }
                            
                           
                    ?>
                    </select>
                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                    <input type="hidden" name="product_id" value="<?php echo $item_id_dec; ?>">
                    <input type="hidden" name="category_id" value="<?php echo $category_id; ?>">
                    <input type="hidden" name="product_image" value="<?php echo $row_selected_item['image']; ?>">
                    <input type="hidden" name="product_name" value="<?php echo $row_selected_item['name']; ?>">
                    <input type="hidden" name="price" value="<?php echo $price; ?>">
                    <input type="hidden" name="size" value="<?php echo $size_dec; ?>">
                        </div>
                    <br>
                    <br>
                    <div class="qty-wrapper">
                    <h3>Select Quantity</h3>
                        <input type="number" value="1" min="1" name="quantity"><br><br>
                    </div>                 

                </div>

                <br>

                <div class="add-cart-button-wrapper">
                <?php
                if($row_selected_item['regular_stock'] == 0 && $row_selected_item['medium_stock'] == 0 && $row_selected_item['large_stock'] == 0 && $row_selected_item['xl_stock'] == 0){
                    echo '<strong style="color:red;">Sorry! This Product is Currently Out of Stock</strong>';
                }else{
                    echo '<button type="submit" class="button" name="add_to_cart">ADD TO CART</button>';
                }              
                                    
                                        
                ?>

                </div>

                
            </div>
            
           
            
           
           
           
            
            
        </div>
    </form>
</div>

        <?php 
            if(isset($_SESSION['cart_feedback'])){
                echo $_SESSION['cart_feedback'];
                unset($_SESSION['cart_feedback']);
            }
        ?>
    <script>
        var param = new URLSearchParams(window.location.search);
        var ui = param.get('ui');
        var pid = param.get('pid');

        var selected = document.getElementById("size");        
            size.addEventListener("change", function(){
                se = btoa(selected.value)
                window.location.href = "item_page.php?ui="+ui+"&&pid="+pid+"&&se="+se+"";
                
        });
    </script>
</body>
</html>
