<?php
include("navbar.php");
include("../fu/db_conn.php");



$id =mysqli_real_escape_string($mysqli, $_GET['ui']);
$user_id = base64_decode($id);





$select_user = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
if(mysqli_num_rows($select_user)){
    $row_user = mysqli_fetch_array($select_user);
    if($row_user['address_home'] != ''){
        $street = $row_user['address_home'];
    }else{
        $street = 'e.g. House No./Street';
    }
    if($row_user['address_brgy'] != ''){
        $barangay = $row_user['address_brgy'];
    }else{
        $barangay = 'Barangay';
    }
    if($row_user['phone'] != ''){
        $phone = $row_user['phone'];
    }else{
        $phone = '9xxxxxxxxx';
    }
}

$select_delivery_fee = $mysqli->query("SELECT * FROM delivery_fee WHERE id = 1");
if(mysqli_num_rows($select_delivery_fee) != 0){
    $row_del_fee = mysqli_fetch_array($select_delivery_fee);
    $minim = $row_del_fee['minim'];
    $maxim = $row_del_fee['maxim'];

}




if(isset($_POST['place_order'])){
    $MOD = $_POST['MOD'];
    $del_ins = $_POST['del_ins'];
    $quantity = $_POST['total_item'];
    $amount = $_POST['total_amount'];
    $sub_total = $_POST['sub_total'];
    $times_used = 0;

    if($sub_total != $amount){
        $discount = 1;
    }else{
        $discount = 0;
    }

    $order_no = generateKey($mysqli);

    $check_add = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
    
    if(mysqli_num_rows($check_add) != 0){
        $row_check_add = mysqli_fetch_array($check_add);
        $fname = $row_check_add['firstname'];
        $lname = $row_check_add['lastname'];
        $back_up_user_id = $row_check_add['id'];
        if($row_check_add['address_home'] != '' && $row_check_add['address_brgy'] != '' && $row_check_add['phone'] != '' && strlen($row_check_add['phone']) == 10){
            $address = $row_check_add['address_home'] . ' ' . $row_check_add['address_brgy'] . ', Zamboanga City';
            $phone = $row_check_add['phone'];

            if($MOD == 'Paypal'){
                $insert_order = $mysqli->query("INSERT INTO orders (user_id, name, order_no, mode_of_payment, del_ins, address, phone, quantity, amount, discount, status, delivery_permission) VALUES ('$user_id', '$fname $lname', '$order_no', '$MOD', '$del_ins' ,'$address', '$phone', '$quantity', '$amount', '$discount', '0', '0')");
                if($insert_order){
                    $order_no_enc = base64_encode($order_no);
                    header("Location: paypal.php?ui=$id&&on=$order_no_enc");
                }
            }elseif($MOD == 'COD'){

                 if (strtolower($row_check_add['address_brgy']) === strtolower('tumaga') || strtolower($row_check_add['address_brgy']) === strtolower('sta maria') || strtolower($row_check_add['address_brgy']) === strtolower('Sta. Maria') || strtolower($row_check_add['address_brgy']) === strtolower('putik') || strtolower($row_check_add['address_brgy']) === strtolower('tetuan') || strtolower($row_check_add['address_brgy']) === strtolower('tugbungan')) {
                    $del_fee += $minim;
                }else{
                    $del_fee += $maxim;
                } 


                $insert_order = $mysqli->query("INSERT INTO orders (user_id, name, order_no, mode_of_payment, del_ins, address, phone, quantity, amount, del_fee, discount, status, delivery_permission) VALUES ('$user_id', '$fname $lname', '$order_no', '$MOD', '$del_ins', '$address', '$phone', '$quantity', '$amount', '$del_fee', '$discount', '0', '1')");
               
                if($insert_order){
                    
                    $from_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$back_up_user_id'");
                    $count = 0;
                    if(mysqli_num_rows($from_cart) != 0){
                        
                        while($row_from_cart = mysqli_fetch_array($from_cart)){
                            $count += 1;
                            $product_id = $row_from_cart['product_id'];
                            $product_image = $row_from_cart['product_image'];
                            $product_name = $row_from_cart['product_name'];
                            $quantity = $row_from_cart['quantity'];
                            $size = $row_from_cart['size'];

                            $to_order_details = $mysqli->query("INSERT INTO order_details (order_no, product_id, product_image, product_name, quantity, size) VALUES ('$order_no', '$product_id', '$product_image', '$product_name', '$quantity', '$size')");
                            if($to_order_details){
                                $select_product = $mysqli->query("SELECT * FROM products WHERE id = '$product_id'");
                                if(mysqli_num_rows($select_product) != 0){
                                    $row_selected = mysqli_fetch_array($select_product);
                                }
                                if($size == 'Regular'){
                                    $new_stock = $row_selected['regular_stock'] - $quantity;
                                    $update_stock = $mysqli->query("UPDATE products SET regular_stock = '$new_stock' WHERE id = '$product_id'");
                                }
    
                                if($size == 'Medium'){
                                    $new_stock = $row_selected['medium_stock'] - $quantity;
                                    $update_stock = $mysqli->query("UPDATE products SET medium_stock = '$new_stock' WHERE id = '$product_id'");
                                }

                                if($size == 'Large'){
                                    $new_stock = $row_selected['large_stock'] - $quantity;
                                    $update_stock = $mysqli->query("UPDATE products SET large_stock = '$new_stock' WHERE id = '$product_id'");
                                }

                                if($size == 'XL'){
                                    $new_stock = $row_selected['xl_stock'] - $quantity;
                                    $update_stock = $mysqli->query("UPDATE products SET xl_stock = '$new_stock' WHERE id = '$product_id'");
                                }
                             
                                    $sales = $row_selected['sold'] + $quantity;
                                    $update_sales = $mysqli->query("UPDATE products SET sold = '$sales' WHERE id = '$product_id'");

                                
                                
                                
                            }
                        }
                    }
                    if($count == mysqli_num_rows($from_cart)){
                        $remove_cart = $mysqli->query("DELETE FROM cart WHERE user_id = '$back_up_user_id'");
                        if($remove_cart){
                            $order_no_enc = base64_encode($order_no);
                            header("Location: trackOrder.php?ui=$id");
                        }
                    }
                    
                }else{
                    $_SESSION['add_error'] = "<div class='add_error'><i class='far fa-exclamation-triangle'></i><br>Failed</div>";
                    header("Location: checkout.php?ui=$id");
                    exit();
                }
            }elseif($MOD == 'Pick-up'){
                $insert_order = $mysqli->query("INSERT INTO orders (user_id, name, order_no, mode_of_payment, del_ins, address, phone, quantity, amount, discount, status, delivery_permission) VALUES ('$user_id', '$fname $lname', '$order_no', '$MOD', '$del_ins', '$address', '$phone', '$quantity', '$amount', '$discount', '0', '0')");
                if($insert_order){
                    $order_no_enc = base64_encode($order_no);
                    header("Location: pick_up.php?ui=$id&&on=$order_no_enc");
                }

            }
        }else{
            $_SESSION['add_error'] = "<div class='add_error'><i class='fas fa-exclamation-triangle'></i><br>Please input delivery address and phone number</div>";
            header("Location: checkout.php?ui=$id");
            exit();
        }
    }
    
}elseif(isset($_POST['delivery_add'])){
    $st = $_POST['street'];
    $brgy = $_POST['barangay'];
    $phone = $_POST['phone'];
    

    if(!ctype_digit($phone)){
            $_SESSION['add_error'] = "<div class='add_error'><i class='fas fa-exclamation-triangle'></i><br>Phone number must be numeric characters</div>" ;
            header("Location: checkout.php?ui=$id");
            exit();
    }elseif(strlen($phone) != 10){
        $_SESSION['add_error'] =  "<div class='add_error'><i class='fas fa-exclamation-triangle'></i><br>Phone number must be 10 digits eg. 9xx xxx xxx</div>";
        header("Location: checkout.php?ui=$id");
        exit();
    }else{

    $insert_add = $mysqli->query("UPDATE users SET address_home = '$st', address_brgy = '$brgy', phone = '$phone' WHERE id = '$user_id' LIMIT 1");

        if($insert_add){
            $_SESSION['add_error'] =  "<div class='add_error' id='success'><i class='fas fa-check'></i><br>Address Added</div>";
            header("Location: checkout.php?ui=$id");
            exit();
        }
    }    
}



//Generate Order no.
function checkKeys($mysqli, $randStr){

    $result = $mysqli->query("SELECT * FROM orders");
    if(mysqli_num_rows($result) != 0){
        while($row = mysqli_fetch_array($result)){
            if($row['order_no'] == $randStr){
                $keyExist = true;
                break;
            }else{
                $keyExist = false;
            }
        }
    }else{
        $keyExist = false;    
    }
    return $keyExist;
}

function generateKey($mysqli){
    $keylength = 11;
    $str = "1234567890";
    $randStr = substr(str_shuffle($str), 0, $keylength);


    $checkKey = checkKeys($mysqli, $randStr);

    while($checkKey == true){
        $randStr = substr(str_shuffle($str), 0, $keylength);
        $checkKey = checkKeys($mysqli, $randStr);
    }

    return $randStr;
}
//End Order no.

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="../css/checkout.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    
<div class="title_section">
    <h3>Checkout</h3>   
</div>


<div class="checkout-wrapper">
<form action="checkout.php?ui=<?php echo $id; ?>" method="POST">

<div class="items-wrapper">
<table>
            
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>

            </tr>
            
            <?php

               
                $select_my_cart = $mysqli->query("SELECT * FROM cart WHERE user_id = '$user_id'");
                if(mysqli_num_rows($select_my_cart) != 0){
                    $sub_total = 0;
                    $total = 0;
                    $total_item = 0;
                    while($row_cart = mysqli_fetch_array($select_my_cart)){
                        $prod_id = $row_cart['product_id'];
                        $psize = $row_cart['size'];
                        $check_product_stock = $mysqli->query("SELECT * FROM products WHERE id = '$prod_id'");
                        $row_product = mysqli_fetch_array($check_product_stock);

                        if($psize == 'Regular'){
                            $stock = $row_product['regular_stock'];
                            
                        }elseif($psize == 'Medium'){
                            $stock = $row_product['medium_stock'];
                        }elseif($psize == 'Large'){
                            $stock = $row_product['large_stock'];
                        }elseif($psize == 'XL'){
                            $stock = $row_product['xl_stock'];
                        }

                        if($stock == 0){
                            header('Location: ../fu/delete_cart_item.php?ui='.$id.'&&cart_id='.$row_cart['id'].'');
                            
                        }elseif($row_cart['quantity']>$stock){
                            $quant = $stock;
                            $update_quantity = $mysqli->query("UPDATE cart SET quantity = '$quant' WHERE product_id = '$prod_id' AND size = '$psize'");
                        
                        }else{
                            $quant = $row_cart['quantity'];
                        }
 
                        $total_item += $quant;
                        $sub_total = $row_cart['price'] * $row_cart['quantity'];
                        $pid = base64_encode($row_cart['product_id']);
                        echo '<tr id="input"> 
                        
                        <td>
                           <div class="cart-info"> 
                                <img src="../admin/products_img/'.$row_cart['product_image'].'" >
                                <div>
                                    <p>'.$row_cart['product_name'].'</p>
                                    <small><i>'.$row_cart['size'].'</i></small>
                                    <br>
                                </div>
                           </div>
                        </td>
                     
                        <td><span>&#8369</span> '.$row_cart['price'].'</td>
                        <td>x'.$quant.'</td>
                        <td><span>&#8369</span> '.number_format($sub_total, 2).'</td>
                        </tr>';


                        $select_user_add = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
                        $row_check_user_add = mysqli_fetch_array($select_user_add);
                        $home = $row_check_user_add['address_home'];
                        $brg = $row_check_user_add['address_brgy'];
                        $cont = $row_check_user_add['phone'];


                        if (strtolower($brg) === strtolower('tumaga') || strtolower($brg) === strtolower('sta maria') || strtolower($brg) === strtolower('Sta. Maria') || strtolower($brg) === strtolower('putik') || strtolower($brg) === strtolower('tetuan') || strtolower($brg) === strtolower('tugbungan')) {
                            $fee = $minim;
                        }else{
                            $fee = $maxim;
                        }

                        $total += $sub_total;
                    }
                }else{
                    $total_item = 0;
                    $total = 0;
                }
            ?>
                    
        </table>
</div>


<br>
    <div class="address-payment-wrapper">
        <div class="address">
        <table id="add" >    
                    <tr>  
                        <td style="text-align: left;"><strong>Delivery Address</strong></td>
                        <td></td>
                    
                    </tr>

                    <tr>
                    <td >Detailed Address: <?php echo $street; ?></td>
                    
                    <td class=td1> <a class="button" onclick="show_add_form()"><b>Edit</b></a>&nbsp;&nbsp;</td>
                    </tr>

                    <tr>
                    <td >Barangay: <?php echo $barangay; ?></td>
                    <td></td>
                    </tr>

                    <tr>
                    <td >City: Zamboanga City</td>
                    <td></td>
                    </tr>

                    <tr>
                    <td ->Contact: +63 <?php echo $phone; ?></td>
                    <td class=td1></td>
                    </tr>
                    <tr>
                        <td>
                    </tr>
                
                </table>

        </div>
        <br>
        <div class="payment">
        <table id="mod" >
                        
                        <tr>
                            <td style="text-align: left;" ><strong>Payment Option</strong></td>
                        </tr>
                            <tr><td></td></tr>
                    
                            
                            
                        <tr>
                            <td class=td1><input type="radio" name="MOD" id="COD" value="COD" checked ><label for="COD">Cash on Delivery</label></td>
                    
                        </tr>

                        <tr>
                            <td id="paypaltd"><input type="radio" name="MOD" value="Paypal" id="paypal"><label for="paypal"><i class="fab fa-paypal"></i>aypal</label></td>
                        </tr>

                        <tr>
                            <td id="paypaltd"><input type="radio" name="MOD" value="Pick-up" id="Pick-up"><label for="Pick-up">Cash on Pick-Up</label></td>
                        </tr>
                
                        <tr><td></td></tr>
                        <tr><td></td></tr>

            </table>
        </div>   
    </div>
    <br>

    <div class="remarks-wrapper">
        <div class="delivery-instruction">
            <span>Delivery Instrction</span>
            <textarea name="del_ins" cols="5" rows="5" class="ins" placeholder="optional"></textarea>
        </div>
        
    </div>

    <br>

    <div class="placeorder-wrapper">        
        <br>
        <table id="placeorder">
        
            <tr>
        
                <td >Items Subtotal</td>
                <td><span>&#8369</span> <?php echo number_format($sub_total, 2); ?></td>
                
            </tr>


            <tr>
            <td style="font-size: 10pt; color:#df313c;" >For COD delivery fee</td>
            <td style="font-size: 10pt; color:#df313c;" ><span>+ &#8369</span> <?php echo number_format($fee, 2); ?></td>
            </tr>
            

            <input type="hidden" id="sub_total" name="sub_total" value="<?php echo $total; ?>" >

            <tr>
                <td>Total Items</td>
                <td id="qty">x<?php echo $total_item; ?></td>    
                <input type="hidden" id="total_item" name="total_item" value="<?php echo $total_item; ?>" >
                <td > 
                    <button type="submit" class="button1" id="place_order" name="place_order"><b>Place Order</b></button>
                </td>
            </tr>
        

            <tr style="font-size: 20px;">
                <td ><b>Total Payment</b></td>
                <td id="tot_pay"><span>&#8369</span> <?php echo number_format($total+$fee, 2); ?></td>
                <input type="hidden" id="total_amount" name="total_amount" value="<?php echo $total; ?>" >
                
                
            </tr>     
            
            <tr>
            

                </tr>
        </table>
    </div>
</form>   

</div>


        
            
                       
                   

 <!--Add Delivery Address-->
 <div class="form-overlay" id="add_delivery_address">
            <div class="form-wrapper">
                <div class="formbox">
                    <div class="banner">
                         <span id="form_title">Edit Delivery Address</span>
                        <div class="cancel" onclick="hide_add_form()"><i class="fas fa-times fa-lg fa-fw"></i></div>
                    </div>

                  
                   
                    <form action="checkout.php?ui=<?php echo $id; ?>" method="POST">
                        <div class="form-control">
                            
                            <div class="first_col">
                                <span>Detailed Address:</span>
                                <input type="text" placeholder="e.g. House No./Street" class="input" required name="street" value="<?php echo $home; ?>">

                                
                                <span>Barangay:</span>
                                <input type="text" placeholder="Barangay" class="input" required name="barangay" value="<?php echo $brg; ?>">

                                <span>Contact:</span>
                                <input type="text" placeholder="+63" class="input" required name="phone" value="<?php echo $cont; ?>">
                            </div>

                            <div class="second_col">
                                <div class="action-btn">
                                    <input type="submit" value="Save" id="create" name="delivery_add">
                                </div>
                            </div>
                           
                        </div>
                    </form>
                   
                </div>
            </div>
</div>



        </div>
        <?php 
            if(isset($_SESSION['add_error'])){
                echo $_SESSION['add_error'];
                unset($_SESSION['add_error']);
            }
        ?>


    <script>
        var add_delivery_address = document.getElementById('add_delivery_address');

        function show_add_form(){
            add_delivery_address.style.display = "block";
        }
        function hide_add_form(){
            add_delivery_address.style.display = "none";
        }
    </script>
  
</body>
</html>
<?php
include("footer.php");
?>
