<?php
include("../fu/db_conn.php");
include("staff_sidebar.php");


$s_id =mysqli_real_escape_string($mysqli, $_GET['si']);
$staff_id = base64_decode($s_id);

$on =mysqli_real_escape_string($mysqli, $_GET['on']);
$st =mysqli_real_escape_string($mysqli, $_GET['st']);
$status = base64_decode($st);
$query = 'WHERE status = '.$status.'';
if($status == 5){
 $category = 'All Orders';
 $query = '';
}elseif($status == 0){
    $category = 'Pending';
    $query = 'WHERE status = '.$status.'';
}elseif($status == 1){
    $category = 'Processing';
}elseif($status == 2){
    $category = 'Out for Delivery';
}elseif($status == 3){
    $category = 'Ready for Pick-up ';
}elseif($status == 4){
    $category = 'Order Received';
}


if(isset($_POST['update_status'])){
    $status_order = $_POST['status'];

    $update_order_status = $mysqli->query("UPDATE orders SET status = '$status_order' WHERE order_no = '$on' LIMIT 1");

    if($update_order_status){
        echo '<script>window.location = "staff_orders.php?si='.$s_id.'&&st='.$st.'&&on=";</script>';
        $_SESSION['message'] = "<div class='success_message'>Status Updated</div>";
        exit();
    }
}





//Update Status
if($on != ''){
    $update_order = $mysqli->query("SELECT * FROM orders WHERE order_no = '$on'");
    if(mysqli_num_rows($update_order) != 0){
        $row_update_order = mysqli_fetch_array($update_order);

        if($row_update_order['mode_of_payment'] == 'Paypal'){
            if($row_update_order['delivery_permission'] == 1){
                $payment_status = 'Paid';
            }else{
                 $payment_status = 'Pending';
            }
        }
        
    }


    echo ' <div class="form-overlay" id="update_status">
    <div class="form-wrapper">
        <div class="formbox" >
            <div class="banner">
                <span id="form_title">Order Details</span>
                <a href="staff_orders.php?si='.$s_id.'&&st='.$st.'&&on=" class="cancel"><i class="fas fa-times fa-lg fa-fw"></i></a>
            </div> 
           
            <form action="staff_orders.php?si='.$s_id.'&&st='.$st.'&&on='.$on.'" method="POST" enctype="multipart/form-data">
                <div class="form-control">
                    <div id="print-order">
                    <div class="first_col">
                        <span class="label">Order I.D.: '.$on.'</span><br>
                        <span class="label">Date&Time: '.$row_update_order['date_ordered'].'</span><br>
                        <span class="label">Payment: '.$row_update_order['mode_of_payment'].'</span><br>';

                        if($row_update_order['mode_of_payment'] == 'Paypal'){
                            echo '<span class="label">Status: '.$payment_status.'</span><br>';
                        }elseif($row_update_order['mode_of_payment'] == 'Pick-up'){
                            echo '<span class="label">Pick-up Time: '.$row_update_order['pick_up_time'].'</span><br>';
                        }

                        echo '
                        <span class="label">Items:</span><br><br>
                            <div id="items_container">
                                    <ul class="label">';
                                $total_items = 0;
                                $order_details = $mysqli->query("SELECT * FROM order_details WHERE order_no = '$on'");
                                if(mysqli_num_rows($order_details) != 0){
                                    while($orders = mysqli_fetch_array($order_details)){
                                        echo '
                                        <li class="details">
                                            <div class="items">
                                                                                  
                                            <img src="../admin/products_img/'.$orders["product_image"].'" alt="">
                                            <div class="item_control">
                                            <span class="item_label">'.$orders["product_name"].'</span>
                                            <span class="item_label">'.$orders["size"].'</span>
                                            <span class="item_label">x'.$orders["quantity"].'</span>


                                            </div>
                                        </li><br>
                                        ';

                                        $total_items += $orders["quantity"];

                                    }
                                }
         
                                    echo '</ul>
                            </div>
                            <div class="inner-col">
                            <div class="first-col">
                            <span class="label">Total Items: x'.$total_items.'</span>
                            <span class="label">Amount: '.$row_update_order['amount'].'</span>
                            <span class="label">Delivery Fee: '.$row_update_order['del_fee'].'</span>
                            <span class="label" style="color:red;">Total: '.number_format($row_update_order['amount']+$row_update_order['del_fee'], 2).'</span>
                            </div>

                            <div class="sec-col" id="exclude">

                            <span class="label">Status</span>
                            <select name="status" id="status" class="input">';
    
                            if($row_update_order['status'] == 0){
                                echo '<option value="0">Pending</option>
                                <option value="1">Processing</option>

                                '.(($row_update_order['mode_of_payment'] == 'Pick-up')?
                                '<option value="3">Ready for Pick-up</option>':
                    
                               '<option value="2">Out for Delivery</option>').'
                               ';
                              
                                
                            }elseif($row_update_order['status'] == 1){
                                echo '<option value="1">Processing</option>
                                <option value="0">Pending</option>

                                '.(($row_update_order['mode_of_payment'] == 'Pick-up')?
                                '<option value="3">Ready for Pick-up</option>':
                    
                               '<option value="2">Out for Delivery</option>').'
                               
                               <option value="4">Received</option>';
                               
                            }elseif($row_update_order['status'] == 2){
                                echo '<option value="2">Out for Delivery</option>
                                <option value="0">Pending</option>
                                <option value="1">Processing</option>
                                <option value="4">Received</option>';
                            }elseif($row_update_order['status'] == 3){
                                echo '<option value="3">Ready for Pick-up</option>
                                <option value="0">Pending</option>
                                <option value="1">Processing</option>
                                <option value="4">Received</option>';
                            }elseif($row_update_order['status'] == 4){
                                echo '<option value="4">Received</option>';
                            }
                            echo '</select>

                           

                            </div>




                            </div>

                                
                        </div><br>

                    <div class="inner-col" id="rem">
                    <span class="label">Remarks</span>
                    <div class="first-col" id="remarks">
                    <div class="description-wrapper">
                    <p>'.$row_update_order['del_ins'].'</p>
                    </div> 
                    </div>
                    </div>
                    </div>           
                    <div class="second_col">
                        <div class="action-btn">
                            <input type="submit" value="Save" id="create" name="update_status">
                            <a href="../fu/invoice_print.php?st='.$st.'&&on='.$on.'" id="download-invoice">Print</a>
                        </div>
                    </div>
                   
                </div>
            </form>
        </div>

        <div class="output" id="output">
        <h1 id="hh">Right Click to Save</h1>
        <a href="#" class="cancel" id="ex" onclick="history.go(-1)"><i class="fas fa-times fa-lg fa-fw"></i></a>
        </div>


    </div>
</div>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/orders.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title> Orders</title>
</head>
-
+
<body>
    <div class="title">
        <div class="col1">
        <h1><?php echo $category; ?></h1>
        
        <select name="category" id="select_cat">
                                    <?php
                                        if($status == 5){
                                            echo '<option value="5">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Ready for Pick-up</option>
                                            <option value="4">Received</option>';
                                        }elseif($status == 0){
                                            echo '<option value="0">Pending</option>
                                            <option value="5">All Orders</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Ready for Pick-up</option>
                                            <option value="4">Received</option>';
                                        }elseif($status == 1){
                                            echo '<option value="1">Processing</option>
                                            <option value="5">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Ready for Pick-up</option>
                                            <option value="4">Received</option>';
                                        }elseif($status == 2){
                                            echo '<option value="2">Out for Delivery</option>
                                            <option value="5">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="3">Ready for Pick-up</option>
                                            <option value="4">Received</option>';
                                        }elseif($status == 3){
                                            echo '<option value="3">Ready for Pick-up</option>
                                            <option value="5">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="4">Order Received</option>';
                                        }elseif($status == 4){
                                            echo '<option value="4">Order Received</option>
                                            <option value="5">All Orders</option>
                                            <option value="0">Pending</option>
                                            <option value="1">Processing</option>
                                            <option value="2">Out for Delivery</option>
                                            <option value="3">Ready for Pick-up</option>';
                                        }

                                    ?>
                                </select>
        </div>
        <div class="col2">
        <form class="search" method="post">
        <input type="text" placeholder="Search.." name="search_value" >
        <button type="submit" name="search"><i class="fa fa-search"></i></button>
        </form>
       

        </div>
    </div>
    
    <div class="content_body">
        <div class="products_section" id="inventory_section">
                <div class="product_table" id="inventory_table">
                        <table class="tables" id="orders_download">
                            <thead>
                                <tr>
                                    <th class="product_name">Order I.D.</th>
                                    <th class="product_large">Date&Time</th>
                                    <th class="product_regular">Customer</th>
                                    <th class="product_medium">Address</th>
                                    <th class="product_large">Contact</th>
                                    <th class="product_overdose">Amount</th>
                                    <th class="product_category" id="last">Status</th>
                                    <th class="product_category" id="last">View</th>
                            
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $s_id =mysqli_real_escape_string($mysqli, $_GET['si']);

                                    $select_all_orders = $mysqli->query("SELECT * FROM orders $query");
                                    if(isset($_POST['search'])){
                                        $search_value = $_POST['search_value'];
                                        if($status == 5){
                                            $search_query = $mysqli->query("SELECT * FROM orders WHERE order_no LIKE '%$search_value%' OR name LIKE '%$search_value%' OR address LIKE '%$search_value%' OR phone LIKE '%$search_value%' ");
                                        }else{

                                        $search_query = $mysqli->query("SELECT * FROM orders WHERE status = '$status' AND (order_no LIKE '%$search_value%' OR name LIKE '%$search_value%' OR address LIKE '%$search_value%' OR phone LIKE '%$search_value%') ");
                                        }
                                    

                                
                                    if(mysqli_num_rows($search_query) != 0){

                                      
                                    
                                        while($row_orders = mysqli_fetch_array($search_query)){
                                            $user_id = $row_orders['user_id'];
                                            $select_user = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
                                            if(mysqli_num_rows($select_user) != 0){
                                                $selected_user = mysqli_fetch_array($select_user);
                                            }
                                            echo '<tr>
                                            <td class="product_name">'.$row_orders['order_no'].'</td>

                                            <td class="product_large">
                                                <span>'.$row_orders['date_ordered'].'</span>
                                            </td>
            
                                            <td class="product_regular">
                                                <span>'.$selected_user['firstname'].'  '.$selected_user['lastname'].'</span>
                                            </td>

                                            
            
                                            <td class="product_medium">
                                                <span>'.$row_orders['address'].'</span>
                                            </td>

                                            <td class="product_medium">
                                            <span>'.$row_orders['phone'].'</span>
                                            </td>
            
                                            
            
                                            <td class="product_overdose">
                                                <span>'.$row_orders['amount'].'</span>
                                            </td>

                                            <td class="product_overdose" style="color:red;">
                                            <span>'.$row_orders['del_fee'].'</span>
                                            </td>';
                                            
                                                if($row_orders['status'] == 0){
                                                    $stat = 'Pending';
                                                }elseif($row_orders['status'] == 1){
                                                    $stat = 'Processing';
                                                }elseif($row_orders['status'] == 2){
                                                    $stat = 'On Delivery';
                                                }elseif($row_orders['status'] == 3){
                                                    $stat = 'Ready for Pick-up';
                                                }elseif($row_orders['status'] == 4){
                                                    $stat = 'Received';
                                                }
                                        
                                            echo '<td class="product_category" id="last">
                                                <span>'.$stat.'</span>
                                            </td>

                                            <td class="product_category" id="last">
                                                <a href="staff_orders.php?si='.$s_id.'&&si='.$s_id.'&&st='.$st.'&&on='.$row_orders['order_no'].'"><i class="fas fa-eye fa-lg fa-fw"></i></a>
                                            </td>

            
                                            </tr>';
                                            
                                            
                                        }
                                    }else{
                                        echo '<tr>
                                            <td colspan=7 style="text-align: center; color: red;">No Orders</td>
                                            </tr>';
                                    }
                                }elseif(mysqli_num_rows($select_all_orders) != 0){

                                      
                                    
                                    while($row_orders = mysqli_fetch_array($select_all_orders)){
                                        $user_id = $row_orders['user_id'];
                                        $select_user = $mysqli->query("SELECT * FROM users WHERE id = '$user_id'");
                                        if(mysqli_num_rows($select_user) != 0){
                                            $selected_user = mysqli_fetch_array($select_user);
                                        }
                                        echo '<tr>
                                        <td class="product_name">'.$row_orders['order_no'].'</td>

                                        <td class="product_large">
                                            <span>'.$row_orders['date_ordered'].'</span>
                                        </td>
        
                                        <td class="product_regular">
                                            <span>'.$selected_user['firstname'].'  '.$selected_user['lastname'].'</span>
                                        </td>

                                        
        
                                        <td class="product_medium">
                                            <span>'.$row_orders['address'].'</span>
                                        </td>
        
                                        <td class="product_medium">
                                        <span>'.$row_orders['phone'].'</span>
                                        </td>
                                        
        
                                        <td class="product_overdose">
                                            <span>'.$row_orders['amount'].'</span>
                                        </td>

                                        <td class="product_overdose" style="color:red;">
                                            <span>'.$row_orders['del_fee'].'</span>
                                        </td>';
                                        
                                        if($row_orders['status'] == 0){
                                            $stat = 'Pending';
                                        }elseif($row_orders['status'] == 1){
                                            $stat = 'Processing';
                                        }elseif($row_orders['status'] == 2){
                                            $stat = 'On Delivery';
                                        }elseif($row_orders['status'] == 3){
                                            $stat = 'Ready for Pick-up';
                                        }elseif($row_orders['status'] == 4){
                                            $stat = 'Received';
                                        }
                                    
                                        echo '<td class="product_category" id="last">
                                            <span>'.$stat.'</span>
                                        </td>

                                        <td class="product_category" id="last">
                                            <a href="staff_orders.php?si='.$s_id.'&&st='.$st.'&&on='.$row_orders['order_no'].'"><i class="fas fa-eye fa-lg fa-fw"></i></a>
                                        </td>
        
                                        </tr>';
                                        
                                        
                                    }
                                }else{
                                    echo '<tr>
                                        <td colspan=7 style="text-align: center; color: red;">No Orders</td>
                                        </tr>';
                                }


                                ?>
                                                    
                            </tbody>

                                <div class="download_button">
                                            <a href="#" id="download_order"><i class="fas fa-print fa-lg fa-fw" style="color: white;"></i></a>
                                            </div>

                        </table>
                </div>

           
        </div>

            
        
    </div> 
    

    <?php
        if(isset($_SESSION['message'])){
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
    ?>


    <script src="../js/staff_orders.js"></script>

    <script type="text/javascript" src="../src/jquery-3.3.1.slim.min.js"></script>

    <script type="text/javascript" src="../src/jspdf.min.js"></script>

    <script type="text/javascript" src="../src/jspdf.plugin.autotable.min.js"></script>

    <script type="text/javascript" src="../src/tableHTMLExport.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.0.0-rc.5/dist/html2canvas.min.js"></script>

    <script type="text/javascript">

    
   

    $("#download_order").on("click",function(){
        $("#orders_download").tableHTMLExport({
        type:'pdf',
        filename:'Orders.pdf',
        ignoreColumns:'#last'
        });
    });


   // Define the function 
        // to screenshot the div
        function takeshot() {

            let div =
                document.getElementById('print-order');

  
            // Use the html2canvas
            // function to take a screenshot
            // and append it
            // to the output div
            html2canvas(div).then(
                function (canvas) {
                    document
                    .getElementById('output')
                    .appendChild(canvas);
                })

                ex.style.display = "block";
                hh.style.display = "block";
        };

        /* function exit_print(){
            print-order.style.display = "none";
        }  */

        $( "#print" ).click(function() {
        $(this).attr("disabled", "disabled");
        $("#unbind").removeAttr("disabled");
        });

    </script>
</body>
</html>