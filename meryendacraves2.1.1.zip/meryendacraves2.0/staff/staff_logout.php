<?php
include("../fu/db_conn.php");

$s_id =mysqli_real_escape_string($mysqli, $_GET['si']);
$staff_id = base64_decode($s_id);


$logout = $mysqli->query("UPDATE admin_staff SET status = '0' WHERE id = '$staff_id' LIMIT 1");

    if($logout){
        unset($_SESSION['auth']);
        header("Location: ../index.php");
    }


?>


