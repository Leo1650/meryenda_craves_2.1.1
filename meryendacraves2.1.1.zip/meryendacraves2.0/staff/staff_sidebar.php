<?php
include("../fu/db_conn.php");
session_start();

if(isset($_GET['si'])){
    $s_id =mysqli_real_escape_string($mysqli, $_GET['si']);
    $staff_id = base64_decode($s_id);
    
    $select_staff = $mysqli->query("SELECT * FROM admin_staff WHERE id = '$staff_id'");
    if(mysqli_num_rows($select_staff) != 0){
        $row_staff = mysqli_fetch_array($select_staff);
    
        if($row_staff['status'] == 0){
           
            header("Location: ../admin/admin_login.php"); 
            exit();
        }
    }
}else{
   
    header("Location: ../admin/admin_login.php"); 
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/sidebar.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <script src="https://kit.fontawesome.com/421b0c86b1.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div class="bg"></div>
    <div class="sidebar">
        <div class="logo"><img src="../img/MCLogo.png" alt="Logo"></div>
        <ul>
            <li><a href="staff_dashboard.php?si=<?php echo $s_id; ?>" id="dashboard">
                <span class="icon"><i class="fas fa-chart-line fa-lg fa-fw"></i></span>
                <span class="sidebar_title">Dashboard</span>
            </a></li>

            <li><a href="staff_orders.php?si=<?php echo $s_id; ?>&&st=NQ==&&on=" id="orders">
                <span class="icon" ><i class="fas fa-tags"></i></span>
                <span class="sidebar_title">Orders</span>
            </a></li>
           

            <li><a href="staff_logout.php?si=<?php echo $s_id; ?>">
                <span class="icon"><i class="fas fa-sign-out-alt fa-lg fa-fw"></i></span>
                <span class="sidebar_title">Logout</span>
            </a></li>

            </ul>
    </div>

    <div class="toggle" onclick="toggleMenu()"></div>

    </div>

    <script>
         function toggleMenu(){
            let sidebar = document.querySelector('.sidebar');
            let toggle = document.querySelector('.toggle');
            let title = document.querySelector('.title');
            
            sidebar.classList.toggle('active');
            toggle.classList.toggle('active');
            title.classList.toggle('active');

        }
    </script>
    </body>
</html>