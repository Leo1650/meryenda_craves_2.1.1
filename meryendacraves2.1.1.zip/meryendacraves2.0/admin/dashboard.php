<?php
include("../fu/db_conn.php");
include("sidebar.php");
session_start();

$aid =mysqli_real_escape_string($mysqli, $_GET['ai']);


$select_all_pending = $mysqli->query("SELECT * FROM orders WHERE status = 0");
if(mysqli_num_rows($select_all_pending) != 0){
    $total_pending = mysqli_num_rows($select_all_pending);
    $row = mysqli_fetch_array($select_all_pending);
}else{
    $total_pending = 0;
}
$select_all_processing = $mysqli->query("SELECT * FROM orders WHERE status = 1");
if(mysqli_num_rows($select_all_processing) != 0){
    $total_processing = mysqli_num_rows($select_all_processing);
}else{
    $total_processing = 0;
}
$select_all_delivery = $mysqli->query("SELECT * FROM orders WHERE status = 2");
if(mysqli_num_rows($select_all_delivery) != 0){
    $total_delivery = mysqli_num_rows($select_all_delivery);
}else{
    $total_delivery = 0;
}

$select_all_pick_up = $mysqli->query("SELECT * FROM orders WHERE mode_of_payment = 'pick-up'");
if(mysqli_num_rows($select_all_pick_up) != 0){
    $total_pick_up = mysqli_num_rows($select_all_pick_up);
}else{
    $total_pick_up = 0;
}

$select_all_sales = $mysqli->query("SELECT * FROM orders WHERE status = 4");
$total_sales = 0;
$sales = '0.00';
if(mysqli_num_rows($select_all_sales) != 0){
    while($row_sales = mysqli_fetch_array($select_all_sales)){

        $product_date_ordered = new DateTime($row_sales['date_ordered']);
        $prduct_date = $product_date_ordered->format('Y-m-d');
        $todays_date = date('Y-m-d');
        //$todays_date = "2021-05-26";

        if($todays_date == $prduct_date){
            $total_sales += $row_sales['amount'];
            $sales = number_format($total_sales, 2);
        }       

    }
}




if(isset($_POST['del_fee'])){
    $min = $_POST['min'];
    $over = $_POST['over'];


    $_SESSION['min_input'] = $min;
    $_SESSION['over_input'] = $over; 
    

    $update_fee = $mysqli->query("UPDATE delivery_fee SET minim = '$min', maxim = '$over' WHERE id = 1");

    if($update_fee){
        unset($_SESSION['min_input']);
        unset($_SESSION['over_input']);
        header("Location: dashboard.php?ai=$aid");
        echo 'Test Lang';
    } 
    



}else{
    echo 'Test';
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title>Dashboard</title>
</head>
<body>
    <div class="title">
        <div class="col1">
            <h1>Dashboard</h1>
        </div>

        <div class="col2">

        <?php

                $get_fee = $mysqli->query("SELECT * FROM delivery_fee WHERE id = 1");
                $row_fee = mysqli_fetch_array($get_fee);



        echo '<form action="dashboard.php" method="POST">
        
       

        <div class="wrap">

        <span style="margin-top:25px; color:#df313c;">Delivery Fee</span>

        <div class="fee-wrap">
        <span>Min</span>
        <input type="number" name="min"  placeholder="0.00" value="'.$row_fee["minim"].'">
        </div>

        <div class="fee-wrap">
        <span>Over</span>
        <input type="number" name="over" placeholder="0.00" value="'.$row_fee["maxim"].'">
        </div>

        
        <div class="fee-wrap">
        <button type="submit" name="del_fee" ><i class="fas fa-plus"></i></button>
        </div>


        
        </div>

        
      
    </form>';
  ?>
        </div>


        
    </div>
        <div class="content">

        <div class="box_wrapper2">
               
               <div class="box2" id="sales">
               <div class="box_content">
                <div class="box_logo">
                   <i class="fas fa-coins fa-lg fa-fw"></i>
                   </div>
                   <div class="text">
                   <span>Daily Sales</span>
                       <h2><span>&#8369</span><?php echo $sales; ?></h2> 
                   </div>
                   
               </div>
               </a>
               </div>

               <div class="box2" id="order"><a href="orders.php?st=MA==&&on=">

                    <div class="box_content">
                        <div class="box_logo">
                        <i class="fas fa-shopping-basket fa-lg fa-fw"></i>
                        </div>
                        <div class="text">
                            <span>Orders</span>
                            <h2><?php echo $total_pending; ?></h2>
                            
                        </div>
                        
                    </div>
                    </a>
                </div>
               
       </div>               


            <div class="box_wrapper">

                <div class="box2" id="processing"><a href="orders.php?st=MQ==&&on=">
                    <div class="box_content">
                        <div class="box_logo">
                        <i class="fas fa-cogs fa-lg fa-fw"></i>
                        </div>
                        <div class="text">
                            <span>Processing</span>
                            <h2><?php echo $total_processing; ?></h2>
                            
                        </div>
                        
                    </div>
                    </a>
                </div>

                <div class="box2" id="delivery"><a href="orders.php?st=Mg==&&on=">
                    <div class="box_content">
                        <div class="box_logo">
                        <i class="fas fa-truck fa-lg fa-fw"></i>
                        </div>
                        <div class="text">
                            <span>On Delivery</span>
                            <h2><?php echo $total_delivery; ?></h2>
                            
                        </div>
                        
                    </div>
                    </a>
                </div>

                

                

            </div>

            

            

                
               
            


        </div>
   

    
        <?php 
            if(isset($_SESSION['message'])){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
        ?>

     
  


    

</body>
</html>