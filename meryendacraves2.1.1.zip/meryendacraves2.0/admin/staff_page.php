<?php
include("../fu/db_conn.php");
include("sidebar.php");
session_start();


if(isset($_POST['add_staff'])){
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $_SESSION['name_input'] = $name;
    $_SESSION['username_input'] = $username;
    $_SESSION['password_input'] = $password;


    if(strlen($name) < 2){
        $_SESSION['name'] = '<p class="add_error">Name must be atleast 2 characters</p>';
        header("Location: staff_page.php");
        exit();
    }


    if(strlen($username) < 5){
        $_SESSION['username'] = '<p class="add_error">Username must be atleast 5 characters</p>';
        header("Location: staff_page.php");
        exit();
    }
    

    if(strlen($password) < 8) {
        $_SESSION['password'] = '<p class="add_error">Password must be atleast 8 characters</p>';
        header("Location: staff_page.php");
        exit();
    }

    if(strlen($name) >= 2 && strlen($username) >= 5  && strlen($password) >= 8){
        $name = $mysqli->real_escape_string($name);
        $username = $mysqli->real_escape_string($username);
        $password = $mysqli->real_escape_string($password);

        $password = md5($password);



        $insert_staff = $mysqli->query("INSERT INTO admin_staff (name, username, password) VALUES ('$name','$username', '$password')");

        if($insert_staff){
            unset($_SESSION['name_input']);
            unset($_SESSION['username_input']);
            unset($_SESSION['password_input']);
            $_SESSION['message'] = "<div class='success_message'>Staff Added</div>";
            header("Location: staff_page.php");
        }else{
            header("Location: staff_page.php");
        }
    }

    
}






?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/staff_page.css">
    <link rel="shortcut icon" type="image/png" href="../img/MCLogo.png">
    <title>Staff</title>
</head>
<body>
    <div class="title">
        <h1>Staff</h1>
    </div>
        <div class="content">

        <div class="add-staff-wrapper">

        <div class="title-wrapper">
            <h1>Add Staff</h1>

            
        </div>
        

        <div class="field-wrapper">
        <form action="staff_page.php" method="POST">

        <div class="field">
        <span>Name</span>
        <input type="text" placeholder="Name" name="name" required>
        <?php
            if(isset($_SESSION['name'])){
                echo $_SESSION['name'];
                unset($_SESSION['name']);
            } 
            unset($_SESSION['name_input']);
        ?>
        </div>

        <div class="field">
        <span>Username</span>
        <input type="text" placeholder="Username" name="username" required>
        <?php
            if(isset($_SESSION['username'])){
                echo $_SESSION['username'];
                unset($_SESSION['username']);
            } 
            unset($_SESSION['username_input']);
        ?>
        </div>


        <div class="field">
        <span>Password</span>
        <input type="password" placeholder="Password" id="password" name="password" required>
        <?php
            if(isset($_SESSION['password'])){
                echo $_SESSION['password'];
                unset($_SESSION['password']);
            } 
            unset($_SESSION['password_input']);
        ?>
        </div>

        <div class="btn">
        <button type="submit" id="submit" name="add_staff">Add</button>
        </div>
        </form>
        </div>

       
           
        

        </div>


        <div class="view-staff-wrapper">
       
            
                    <table >
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Username</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $get_staff = $mysqli->query("SELECT * FROM admin_staff ORDER BY status desc");
                            if(mysqli_num_rows($get_staff) != 0){
                                while($row_staff = mysqli_fetch_array($get_staff)){
                                    $staff_id = base64_encode($row_staff['id']);

                                    echo '
                                    <tr>
                                    <td>'.$row_staff['name'].'</td>
                                    <td>'.$row_staff['username'].'</td>

                                    '.(($row_staff['status'] == 1)?'
                                    <td style="color: #00a651;">Active</td>
                                    '
                                    :'
                                    <td style="color: #df313c;">Inactive</td>
                                    ').'
                                    
                                    <td> <a href="../fu/remove_staff.php?sid='.$row_staff['id'].'"><i class="fas fa-trash fa-lg fa-fw"></i></a></td>
                                </tr>
                                    ';
                                }
                            }



                           
                        
                            ?>
                        </tbody>
                    </table>
            
        
        </div>

       
            


        </div>
    
        <?php 
            if(isset($_SESSION['message'])){
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
        ?>

     
  
    </script>
    

</body>
</html>